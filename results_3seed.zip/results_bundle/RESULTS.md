# Results package (2026-10-07 03:12)

- steps completed: **61**, failed: **0**, skipped: **0**

## Settings used

| setting | value |
|---|---|
| window / stride | 20 / 2 |
| block size (flows) | 4000 |
| split (train/val/test) | (0.7, 0.1, 0.2) |
| window label | last |
| features selected | 35 |
| max train windows (CNN) | 800,000 |
| max train windows (GBM) | 400,000 |
| max epochs / patience | 12 / 3 |
| max eval windows | 500,000 |
| de-duplication | True |
| Pre-Attack definition | Infiltration + PortScan (LABEL_RULES in config.py) |

## Main results (test blocks; mean ± std over the seeds that finished)

`test` = argmax of the model; `test_tuned` = class scales tuned on validation only. Compare models on `Pre_AP` and `macro_f1` first. A difference smaller than the ± spread (or with n_seeds = 1) is not evidence of a better model.

| run | split | n_seeds | macro_f1 | Pre_f1 | Pre_AP | Infil_rec | PortScan_rec | Atk_f1 | acc |
|---|---|---|---|---|---|---|---|---|---|
| attn | test | 3 | 0.8365 ± 0.0102 | 0.5424 ± 0.0268 | 0.7134 ± 0.0106 | 0.7203 ± 0.0850 | 0.9988 ± 0.0009 | 0.9953 ± 0.0023 | 0.9539 ± 0.0080 |
| attn | test_tuned | 3 | 0.8575 ± 0.0061 | 0.5888 ± 0.0200 | 0.7134 ± 0.0106 | 0.3154 ± 0.0849 | 0.9987 ± 0.0003 | 0.9971 ± 0.0012 | 0.9774 ± 0.0015 |
| ens | test | 3 | 0.8728 ± 0.0017 | 0.6347 ± 0.0050 | 0.7515 ± 0.0064 | 0.5623 ± 0.0158 | 0.9973 ± 0.0003 | 0.9992 ± 0.0000 | 0.9742 ± 0.0002 |
| ens | test_tuned | 3 | 0.8728 ± 0.0017 | 0.6347 ± 0.0050 | 0.7515 ± 0.0064 | 0.5623 ± 0.0158 | 0.9973 ± 0.0003 | 0.9992 ± 0.0000 | 0.9742 ± 0.0002 |
| ensattn | test | 3 | 0.8729 ± 0.0009 | 0.6347 ± 0.0027 | 0.7519 ± 0.0035 | 0.5609 ± 0.0121 | 0.9978 ± 0.0004 | 0.9992 ± 0.0001 | 0.9743 ± 0.0001 |
| ensattn | test_tuned | 3 | 0.8729 ± 0.0009 | 0.6347 ± 0.0027 | 0.7519 ± 0.0035 | 0.5609 ± 0.0121 | 0.9978 ± 0.0004 | 0.9992 ± 0.0001 | 0.9743 ± 0.0001 |
| gbm | test | 3 | 0.8712 ± 0.0003 | 0.6297 ± 0.0008 | 0.7448 ± 0.0006 | 0.5455 ± 0.0014 | 0.9971 ± 0.0003 | 0.9992 ± 0.0001 | 0.9742 ± 0.0000 |
| gbm | test_tuned | 3 | 0.8712 ± 0.0003 | 0.6297 ± 0.0008 | 0.7448 ± 0.0006 | 0.5455 ± 0.0014 | 0.9971 ± 0.0003 | 0.9992 ± 0.0001 | 0.9742 ± 0.0000 |
| gbm_2017to2018 | test | 3 | 0.4707 ± 0.0102 | 0.0584 ± 0.0018 | 0.0452 ± 0.0011 | 0.032 ± 0.0012 | nan | 0.4102 ± 0.0280 | 0.8934 ± 0.0020 |
| gbm_2017to2018 | test_tuned | 3 | 0.4707 ± 0.0102 | 0.0584 ± 0.0018 | 0.0452 ± 0.0011 | 0.032 ± 0.0012 | nan | 0.4102 ± 0.0280 | 0.8934 ± 0.0020 |
| gbm_2018to2017 | test | 3 | 0.4851 ± 0.0390 | 0.1474 ± 0.0847 | 0.1388 ± 0.0599 | 0.1358 ± 0.0959 | nan | 0.4215 ± 0.0889 | 0.8071 ± 0.0213 |
| gbm_2018to2017 | test_tuned | 3 | 0.4851 ± 0.0390 | 0.1474 ± 0.0847 | 0.1388 ± 0.0599 | 0.1358 ± 0.0959 | nan | 0.4215 ± 0.0889 | 0.8071 ± 0.0213 |
| lgbm | test | 3 | 0.8449 ± 0.0005 | 0.5619 ± 0.0015 | nan | nan | nan | 0.9926 ± 0.0001 | 0.967 ± 0.0002 |
| lgbm_2017to2018 | test | 3 | 0.3432 ± 0.0095 | 0.0544 ± 0.0064 | nan | nan | nan | 0.0482 ± 0.0283 | 0.8619 ± 0.0027 |
| lgbm_2018to2017 | test | 3 | 0.4217 ± 0.0049 | 0.0363 ± 0.0109 | nan | nan | nan | 0.3609 ± 0.0115 | 0.7743 ± 0.0037 |
| none | test | 3 | 0.8582 ± 0.0036 | 0.5989 ± 0.0105 | 0.7122 ± 0.0161 | 0.555 ± 0.1177 | 0.9979 ± 0.0012 | 0.9943 ± 0.0032 | 0.9689 ± 0.0047 |
| none | test_tuned | 3 | 0.8645 ± 0.0026 | 0.6132 ± 0.0062 | 0.7122 ± 0.0161 | 0.4601 ± 0.0862 | 0.9974 ± 0.0017 | 0.9956 ± 0.0024 | 0.9743 ± 0.0018 |
| rand_gbm | test | 3 | 0.9047 ± 0.0004 | 0.7275 ± 0.0011 | 0.8547 ± 0.0003 | 0.719 ± 0.0017 | 0.9981 ± 0.0005 | 0.9992 ± 0.0001 | 0.9784 ± 0.0001 |
| rand_gbm | test_tuned | 3 | 0.9104 ± 0.0003 | 0.7424 ± 0.0007 | 0.8547 ± 0.0003 | 0.5795 ± 0.0033 | 0.9976 ± 0.0003 | 0.9992 ± 0.0001 | 0.9822 ± 0.0000 |
| rand_weights | test | 3 | 0.8502 ± 0.0037 | 0.5836 ± 0.0083 | 0.7945 ± 0.0095 | 0.7811 ± 0.0451 | 0.9989 ± 0.0004 | 0.9936 ± 0.0026 | 0.9555 ± 0.0032 |
| rand_weights | test_tuned | 3 | 0.8891 ± 0.0022 | 0.6826 ± 0.0059 | 0.7945 ± 0.0095 | 0.3774 ± 0.0234 | 0.9985 ± 0.0003 | 0.9965 ± 0.0005 | 0.9801 ± 0.0005 |
| sampler | test | 3 | 0.8017 ± 0.0157 | 0.4571 ± 0.0373 | 0.7169 ± 0.0059 | 0.8863 ± 0.0227 | 0.9992 ± 0.0003 | 0.9947 ± 0.0021 | 0.9249 ± 0.0122 |
| sampler | test_tuned | 3 | 0.8599 ± 0.0059 | 0.6021 ± 0.0159 | 0.7169 ± 0.0059 | 0.5576 ± 0.0699 | 0.9989 ± 0.0003 | 0.9957 ± 0.0027 | 0.9695 ± 0.0041 |
| smote | test | 3 | 0.8586 ± 0.0043 | 0.5993 ± 0.0108 | 0.6838 ± 0.0122 | 0.4061 ± 0.0205 | 0.9963 ± 0.0012 | 0.992 ± 0.0012 | 0.9737 ± 0.0020 |
| smote | test_tuned | 3 | 0.8595 ± 0.0029 | 0.6014 ± 0.0075 | 0.6838 ± 0.0122 | 0.3791 ± 0.0264 | 0.9962 ± 0.0014 | 0.992 ± 0.0012 | 0.9749 ± 0.0008 |
| train2017_test2018 | test | 3 | 0.4432 ± 0.0261 | 0.0497 ± 0.0219 | 0.0451 ± 0.0037 | 0.0304 ± 0.0150 | nan | 0.3849 ± 0.0588 | 0.8175 ± 0.0598 |
| train2017_test2018 | test_tuned | 3 | 0.4432 ± 0.0261 | 0.0497 ± 0.0219 | 0.0451 ± 0.0037 | 0.0304 ± 0.0150 | nan | 0.3849 ± 0.0588 | 0.8175 ± 0.0598 |
| train2018_test2017 | test | 3 | 0.2139 ± 0.0995 | 0.0633 ± 0.0151 | 0.0814 ± 0.0881 | 0.8172 ± 0.3003 | nan | 0.0103 ± 0.0034 | 0.387 ± 0.2517 |
| train2018_test2017 | test_tuned | 3 | 0.2532 ± 0.0806 | 0.0697 ± 0.0159 | 0.0814 ± 0.0881 | 0.7358 ± 0.4214 | nan | 0.0087 ± 0.0021 | 0.4908 ± 0.2338 |
| weights | test | 3 | 0.8323 ± 0.0078 | 0.5324 ± 0.0181 | 0.7203 ± 0.0157 | 0.7686 ± 0.0229 | 0.9982 ± 0.0010 | 0.9949 ± 0.0031 | 0.9501 ± 0.0036 |
| weights | test_tuned | 3 | 0.8587 ± 0.0081 | 0.5928 ± 0.0217 | 0.7203 ± 0.0157 | 0.3117 ± 0.0515 | 0.9976 ± 0.0012 | 0.9964 ± 0.0023 | 0.9777 ± 0.0006 |

## Step log

| step | status | seconds | note |
|---|---|---|---|
| prepare | done | 653 | 2 attempts |
| seq_pooled | done | 88 |  |
| lgbm_s1 | done | 256 |  |
| gbm_s1 | done | 208 |  |
| none_s1 | done | 144 |  |
| weights_s1 | done | 179 |  |
| sampler_s1 | done | 151 |  |
| smote_s1 | done | 133 |  |
| attn_s1 | done | 354 |  |
| ens_s1 | done | 6 |  |
| ensattn_s1 | done | 6 |  |
| lgbm_s2 | done | 263 |  |
| gbm_s2 | done | 208 |  |
| none_s2 | done | 93 |  |
| weights_s2 | done | 113 |  |
| sampler_s2 | done | 113 |  |
| smote_s2 | done | 147 |  |
| attn_s2 | done | 165 |  |
| ens_s2 | done | 6 |  |
| ensattn_s2 | done | 6 |  |
| lgbm_s3 | done | 251 |  |
| gbm_s3 | done | 200 |  |
| none_s3 | done | 221 |  |
| weights_s3 | done | 211 |  |
| sampler_s3 | done | 232 |  |
| smote_s3 | done | 131 |  |
| attn_s3 | done | 246 |  |
| ens_s3 | done | 6 |  |
| ensattn_s3 | done | 6 |  |
| seq_random | done | 181 | 2 attempts |
| rand_weights_s1 | done | 162 |  |
| rand_gbm_s1 | done | 210 |  |
| rand_weights_s2 | done | 210 |  |
| rand_gbm_s2 | done | 279 |  |
| rand_weights_s3 | done | 125 |  |
| rand_gbm_s3 | done | 203 |  |
| cleanup_random | done | 0 |  |
| seq_cic2017 | done | 180 | 2 attempts |
| train2018_test2017_s1 | done | 173 |  |
| gbm_2018to2017_s1 | done | 190 |  |
| lgbm_2018to2017_s1 | done | 256 |  |
| train2018_test2017_s2 | done | 216 |  |
| gbm_2018to2017_s2 | done | 259 |  |
| lgbm_2018to2017_s2 | done | 253 |  |
| train2018_test2017_s3 | done | 101 |  |
| gbm_2018to2017_s3 | done | 185 |  |
| lgbm_2018to2017_s3 | done | 248 |  |
| cleanup_cic2017 | done | 0 |  |
| seq_cic2018 | done | 188 | 2 attempts |
| train2017_test2018_s1 | done | 144 |  |
| gbm_2017to2018_s1 | done | 64 |  |
| lgbm_2017to2018_s1 | done | 109 |  |
| train2017_test2018_s2 | done | 193 |  |
| gbm_2017to2018_s2 | done | 67 |  |
| lgbm_2017to2018_s2 | done | 100 |  |
| train2017_test2018_s3 | done | 131 |  |
| gbm_2017to2018_s3 | done | 67 |  |
| lgbm_2017to2018_s3 | done | 93 |  |
| cleanup_cic2018 | done | 0 |  |
| final_eval | done | 75 |  |
| final_collect | done | 1 | 2 attempts |
| final_bundle | running | 0 | attempt 2 |
